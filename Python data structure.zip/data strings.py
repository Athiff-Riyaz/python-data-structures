x="hello"
print(x)
#special characters
print('one \ntwo \nthree')
print('brian\'s mother: he\'s not an angel.')
#\ back slash is a escape character

#accessing strings
print(x[2])
print(x[-1])
#loop
for c in x:
    print(c)