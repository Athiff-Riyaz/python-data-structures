#the 'in' operation can be used to check if a string is part of another string.
x="i love python"
if "python" in x:
    print("yes")
#concatenation
print("athiff"+'riyaz')
print("athiff"*3)
print(4*'2')
#operators
print(x.count("o"))
print(x.upper())
print(x.lower())
print(x.replace("python", "java"))
print(len(x))