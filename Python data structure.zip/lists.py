names=["james","tom","amy"]
print(names[1])
m=[
    [1,2,3],
    [4,5,6]
]
print(m[1][2])

words=["athiff","munsif","zulaiha"]
print("athiff" in words)
print("munsif" in words)
print("zulaiha" in words)
x=[2,4,6,8]
for n in x:
    print(n)