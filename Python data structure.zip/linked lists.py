#node
class node:
    def__init__(self,data,next):
         self.data=Data  
         self.next=next
         
