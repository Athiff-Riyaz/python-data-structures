first={1,2,3,4,5,6}
second={4,5,6,7,8,9}
print(first| second)
print(first & second)
print(first - second)
print(second-first)
print(first^second)
#&=intersection
#|=union
#-=difference
#^=add difference