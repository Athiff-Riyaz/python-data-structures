x=[2,4,6]
x.append(8)
x.remove(4)
x.insert(0,8)
print(x)
print(x.count(8))
x.reverse()
print(x)

x.sort()
print(x)

print(min(x))
print(max(x))
